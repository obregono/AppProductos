package com.unison.appproductos.views
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*


import androidx.navigation.NavHostController
import androidx.compose.ui.unit.dp

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.unison.appproductos.R

@Composable
fun Inicio(
    onProductosClick: () -> Unit,
    onPresentacionClick: () -> Unit,
    navController: NavHostController
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally, // Contenido centrado horizontalmente
        verticalArrangement = Arrangement.Center // Contenido centrado verticalmente
    ) {
        // Logo animado
        Image(
            painter = painterResource(id = R.drawable.logo_empresa),
            contentDescription = "Logo de la Empresa",
            modifier = Modifier.size(150.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Nombre de la empresa
        Text(
            text = "Mi Empresa",
            style = MaterialTheme.typography.displayMedium
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Botones mejorados
        Button(onClick = onProductosClick) {
            Text("Productos")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = onPresentacionClick) {
            Text("Presentación")
        }
    }
}
