package com.unison.appproductos.navigation

object NavDestinations {
    const val INICIO = "inicio"
    const val FORMULARIO = "formulario"
    const val CARTA_PRESENTACION = "carta_presentacion"
    const val LISTADO = "listado"
}
