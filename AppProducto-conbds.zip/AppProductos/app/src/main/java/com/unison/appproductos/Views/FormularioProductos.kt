package com.unison.appproductos.views

import android.app.DatePickerDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import com.unison.appproductos.viewmodels.ProductosViewModel
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormularioProductos(
    viewModel: ProductosViewModel,
    onAgregarClick: () -> Unit,
    navController: NavHostController
) {
    var nombre by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var precio by remember { mutableStateOf("") }
    var fechaRegistro by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val context = LocalContext.current
    val calendar = Calendar.getInstance()

    // Configuración del DatePicker para elegir la fecha
    val datePickerDialog = remember {
        DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                fechaRegistro = String.format("%02d/%02d/%04d", dayOfMonth, month + 1, year)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
    }

    // Validación de los campos
    fun validarCampos(): Boolean {
        return when {
            nombre.isEmpty() -> {
                errorMessage = "El nombre es obligatorio."
                false
            }
            descripcion.isEmpty() -> {
                errorMessage = "La descripción es obligatoria."
                false
            }
            precio.isEmpty() || precio.toDoubleOrNull() == null -> {
                errorMessage = "El precio es obligatorio y debe ser un número válido."
                false
            }
            fechaRegistro.isEmpty() -> {
                errorMessage = "La fecha de registro es obligatoria."
                false
            }
            else -> {
                errorMessage = ""
                true
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Formulario de Productos") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigate("listado") }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Flecha hacia atrás")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (validarCampos()) {
                        viewModel.agregarProducto(nombre, descripcion, precio.toDouble(), fechaRegistro)
                        onAgregarClick()
                        navController.navigate("listado")
                    }
                },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Agregar Producto")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.Center
        ) {
            // Campo para el nombre
            TextField(
                value = nombre,
                onValueChange = { nombre = it },
                label = { Text("Nombre del Producto") },
                modifier = Modifier.fillMaxWidth(),
                isError = nombre.isEmpty()
            )
            if (nombre.isEmpty()) {
                Text(text = "Este campo es obligatorio", color = MaterialTheme.colorScheme.error)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Campo para la descripción
            TextField(
                value = descripcion,
                onValueChange = { descripcion = it },
                label = { Text("Descripción") },
                modifier = Modifier.fillMaxWidth(),
                isError = descripcion.isEmpty()
            )
            if (descripcion.isEmpty()) {
                Text(text = "Este campo es obligatorio", color = MaterialTheme.colorScheme.error)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Campo para el precio
            TextField(
                value = precio,
                onValueChange = { precio = it },
                label = { Text("Precio") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                isError = precio.isEmpty() || precio.toDoubleOrNull() == null
            )
            when {
                precio.isEmpty() -> Text(text = "Este campo es obligatorio", color = MaterialTheme.colorScheme.error)
                precio.toDoubleOrNull() == null -> Text(text = "Debe ser un número válido", color = MaterialTheme.colorScheme.error)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Campo para la fecha de registro
            TextField(
                value = fechaRegistro,
                onValueChange = { fechaRegistro = it },
                label = { Text("Fecha de Registro") },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { datePickerDialog.show() }, // Abre el DatePicker al hacer clic
                readOnly = true, // Campo de fecha solo lectura
                isError = fechaRegistro.isEmpty()
            )
            if (fechaRegistro.isEmpty()) {
                Text(text = "Este campo es obligatorio", color = MaterialTheme.colorScheme.error)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Mensaje de error
            if (errorMessage.isNotEmpty()) {
                Text(text = errorMessage, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
